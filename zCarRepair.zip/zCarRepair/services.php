<?php
include("cheader.php");
if(isset($_POST['submit']))
 {
	$q=mysqli_query($con,"insert into booking_services values(null,'".$_SESSION['un']."','".$_POST['sid']."','".date('y-m-d')."','".$_POST['price']."') ");
 }
											
											 
?>
                </div>
            </header>
            
            <!--==============================content================================-->
            <section id="content">
                <div class="main zerogrid">
                    <div class="col-full">
                       <form method="post">
                        <div class="container-bot">
                            <div class="container-top">
                                <div class="container">
                                    <div class="wrapper">
                                        <article class="col-2-3"><div class="wrap-col">
                                            <div>
											<?php
											$q=mysqli_query($con,"select * from services ");
											while($q1=mysqli_fetch_array($q)) {
												$sid=$q1['S_id'];
											?>
                                                <h3><font color="Tomato"><?php echo $q1['S_name']; ?></font></h3>
                                                <div class="wrapper margin-bot">
													<div class="col-1-3">
                                                    <figure class="img-indent3"><img src="Admin/<?php echo $q1['Image'];?>" alt=""></figure>
													</div>
                                                    <div class="col-2-3 extra-wrap">
                                                        <h6><strong>CR Price :<?php  echo 'Rs. '.$q1['Price'];?> </strong></h6>
                                                        <p><?php echo $q1['Description'];?></p>
														
														
                                                        <a class="button" href="booked.php?id=<?php echo $sid?>" name="book">Book</a>
														<input type="hidden" value="<?php echo $sid; ?>" name='sid'>
															<input type="hidden" value="<?php echo $q1['Price']; ?>" name='price'>
													
													
                                                    </div>
                                                </div>
                                             <?php 
											}
										
											 
											
											 
											 
											 ?>  
                                            </div>
                                        </div></article>
                                        
                                    </div>
                                </div>
                            </div>
                        </div></form>
                    </div>
                </div>
            </section>
            
            <!--==============================footer=================================-->
           <?php
		   
		   include("cfooter.php");
		   ?>