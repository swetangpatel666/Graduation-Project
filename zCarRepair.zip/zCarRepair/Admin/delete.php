<?php
$con=mysqli_connect("localhost","root","","car_services");

if($_GET['id'])
{
	$q=mysqli_query($con,"delete from package where package_id='".$_GET['id']."'");
	header("location:viewpkg.php");  
}
?>
	
