Cufon.replace('h2, h3, .text-1', { fontFamily: 'Vegur', hover:true });
Cufon.replace('.text-2', { fontFamily: 'Vegur L', hover:true });
