<?php
include("header.php");
if(isset($_POST['submit']))
{
	for($i=0;$i<count($_FILES['file_img']['name']);$i++)
	{
		$filetemp=$_FILES["file_img"]["tmp_name"][$i];
		$filename=$_FILES["file_img"]["name"][$i];
		$filetype=$_FILES["file_img"]["type"][$i];
		
		$filepath="".$filename;
		move_uploaded_file($filetemp,$filepath);
		$qry=mysqli_query($con,"insert into services values(null,'".$_POST['S_name']."','".$_POST['Description']."','$filepath','".$_POST['Price']."')");
		$result=mysqli_query($con,$qry);
	}

}
?>
<section id="content">
                <div class="main zerogrid">
                    <div class="col-full">
                        <div class="row" style="margin: 30px 0;">
                           
                           
                        </div>
                        <div class="container-bot">
                            <div class="container-top">
                                <div class="container">
                                    <div class="wrapper">
                                        <article class="col-2-3"><div class="wrap-col">
                                            <div class="indent-left">
                                                <h3 class="p1">Service  </h3>
                                                <form id="contact-form" method="post" enctype="multipart/form-data">                    
                                                    <fieldset>
                                            <tr>             
									<td><label><span class="text-form">Services:</span><input name="S_name" type="text" required /></label>
									<label><span class="text-form">Description:</span><input name="Description"  type="text" required /></label>
											<label><span class="text-form">images:</span><input type="file" name="file_img[]" required /></label>
						  <label><span class="text-form">Price:</span><input name="Price" type="text" /></label></td>
															
											</tr>				
														
														 <div class="wrapper">
                                                            
                                                            <div class="extra-wrap">
															
                                                                <div class="Sign Up"></div>
                                                                <div class="buttons" style="text-align: center;">
																
																<input type="submit" class="button" value="Submit" style="width:100px;background-color:orange;" name="submit"/>
																		
																<a href="Viewdel.php"><u>View Detail</u> </a>
                                                                </div> 
                                                            </div>
                                                          </div>   
																			  
                                                    </fieldset>						
                                                </form>
                                            </div>
                                        </div></article>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>			

<?php
 include("footer.php");
 ?>