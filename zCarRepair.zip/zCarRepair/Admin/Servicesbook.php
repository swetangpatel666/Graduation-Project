<?php
include("header.php");
if(isset($_POST['submit']))
{
$qry=mysqli_query($con,"insert into booking_services values(null,null,'".$_POST['Date']."','".$_POST['Time']."','".$_POST['Price']."')");
echo "Detail Inserted Successfully";
}
else
{
echo "Something Wrong";
}
?>
<section id="content">
                <div class="main zerogrid">
                    <div class="col-full">
                        <div class="row" style="margin: 30px 0;">
                           
                           
                        </div>
                        <div class="container-bot">
                            <div class="container-top">
                                <div class="container">
                                    <div class="wrapper">
                                        <article class="col-2-3"><div class="wrap-col">
                                            <div class="indent-left">
                                                <h3 class="p1">Book Service  </h3>
                                                <form id="contact-form" method="post" enctype="multipart/form-data">                    
                                                    <fieldset>
                                                         
                        <label><span class="text-form">Date:</span><input name="Date" type="text" /></label>
						<label><span class="text-form">Time:</span><input name="Time" type="text" /></label>
						<label><span class="text-form">Price:</span><input name="Price" type="text" /></label>
															
															
														
														 <div class="wrapper">
                                                            
                                                            <div class="extra-wrap">
															
                                                                <div class="Sign Up"></div>
                                                                <div class="buttons" style="text-align: center;">
																
																<input type="submit" class="button" value="Submit" style="width:100px;background-color:orange;" name="submit"/>
																		
																<a href="Viewdetail1.php"><u>View Detail</u> </a>
                                                                </div> 
                                                            </div>
                                                          </div>   
																			  
                                                    </fieldset>						
                                                </form>
                                            </div>
                                        </div></article>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>			

<?php
 include("footer.php");
 ?>