<?php
include("header.php");
$con=mysqli_connect("localhost","root","","car_services");
?>
<section id="content">
                <div class="main zerogrid">
                    <div class="col-full">
                        <div class="row" style="margin: 30px 0;">
                           
                           
                        </div>
                        <div class="container-bot">
                            <div class="container-top">
                                <div class="container">
                                    <div class="wrapper">
                                        <article class="col-2-3"><div class="wrap-col">
                                            <div class="indent-left">
                                        <center>        <h3 class="p1">Detail Report</h3>
                                        <form method="post" action="<?php $_PHP_SELF ?>">
											<table style="100%"  cellpadding="2">
														<tr>
														<th>Name</th>
														<th>Phone </th>
														<th>Address</th>
														<th>City</th>
														<th>PinCode</th>
														</tr>
													<?php
														$qry=mysqli_query($con,"select *from customer");
														while($qry1=mysqli_fetch_assoc($qry)){
													?>
											<tr>
												<th><?php echo $qry1['Name']; ?></th>
												<th><?php echo $qry1['Phone']; ?></th>
												<th><?php echo $qry1['Address']; ?></th>
												<th><?php echo $qry1['City']; ?></th>
												<th><?php echo $qry1['Pin code']; ?></th>
												
											</tr>
											<?php } ?>
											</table>
											<a href="FeedReport.php">Feedback</a>
										</form></center>
                                            </div>
                                        </div></article>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
<?php
include("footer.php");
?>