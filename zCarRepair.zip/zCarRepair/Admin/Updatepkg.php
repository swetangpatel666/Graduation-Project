<?php
include("header.php");
//$con=mysqli_connect("localhost","root","","car_services");
$q=mysqli_query($con,"select * from services where package_id='".$_GET['uid']."'");
$q1=mysqli_fetch_array($q);

if(isset($_POST['submit']))
{
	$qry=mysqli_query($con,"update services set Package_name='".$_POST['Package_name']."' where package_id='".$_GET['uid']."'");
	header("location:viewpkg.php");
	
}
else
{
	echo"";
}
?>

<section id="content">
                <div class="main zerogrid">
                    <div class="col-full">
                        <div class="row" style="margin: 30px 0;">
                           
                           
                        </div>
                      <div class="container-bot">
                            <div class="container-top">
                                <div class="container">
                                    <div class="wrapper">
                                        <article class="col-2-3"><div class="wrap-col">
                                            <div class="indent-left">
                                                <h3 class="p1">Packages</h3>
                                              <form method="post" action="<?php $_PHP_SELF ?>">
														<fieldset>
														<table align="center" border=1>
                                                        <tr>
														<td><label><span class="text-form">Package id:</span><input name="package_id" type="Number" value="<?php echo $q1['package_id'];?>" style="padding:3px" /></label></td>                          
														<td><label><span class="text-form">Package:</span><select name="Package_name" style="width:343px;padding:3px;">
																											<option value="basic" name="Basic">Basic</option>
																											<option value="premium" name="Premium">Premium</option>
																											<option value="elite" name="Elite">Elite</option>
																											</select></td>  
														<td><label style="height:40px;"><span class="text-form">Service:</span><select name="service" multiple >
																										<option value=""  style="width:343px;">Select Services</option>
																										<?php
																										$q=mysqli_query($con,"select * from services");
																											while($q1=mysqli_fetch_array($q)){
																										?>
																										<option value="<?php echo $q1['S_id'];?>"><?php echo $q1['S_name'];?></option>
																										<?php } ?>
																										</select>									
														<td><label><span class="text-form">Description:</span><input name="Description" type="text" value="<?php echo $q1['Description'];?>" style="padding:3px"/></label></td>  
														<td><label><span class="text-form">Price:</span><input name="Price" type="text" value="<?php echo $q1['Price'];?>" style="padding:3px" /></label></td>  
														</tr>														
														</table>	
														
														
														 <div class="wrapper">
                                                            
                                                            <div class="extra-wrap">
															
                                                           
                                                                <div class="buttons" style="text-align: center;">
																
																<input type="submit" class="button" value="submit" style="width:100px;background-color:orange;" name="submit"/>
																		
                                                                </div> 
                                                            </div>
                                                          </div>   
																			  
                                                    </fieldset>
</form>
                                            </div>
                                        </div></article>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
		
<?php
include("footer.php");
?>

												