<?php
include("header.php");
$con=mysqli_connect("localhost","root","","car_services");
?>
<style>
table ,th,td
{
	border:2px solid grey;
}
</style>
<section id="content">
                <div class="main zerogrid">
                    <div class="col-full">
                        <div class="row" style="margin: 30px 0;">
                           
                           
                        </div>
                        <div class="container-bot">
                            <div class="container-top">
                                <div class="container">
                                    <div class="wrapper">
                                        <article class="col-2-3"><div class="wrap-col">
                                            <div class="indent-left">
                                        <center>        <h3 class="p1">View Services  </h3>
                                        <form method="post" action="<?php $_PHP_SELF ?>">
											<table style="100%"  cellpadding="2">
														<tr>
														<th>Service Id</th>
														<th>Services</th>
														<th>Description</th>
														<th>Image</th>
														<th>Price</th>
														<th>Actions</th>
														</tr>
													<?php
														$qry=mysqli_query($con,"select *from services");
														while($qry1=mysqli_fetch_assoc($qry)){
													?>
											<tr>
												<th><?php echo $qry1['S_id']; ?></th>
												<th><?php echo $qry1['S_name']; ?></th>
												<th><?php echo $qry1['Description']; ?></th>
												<th><img src="<?php echo $qry1['Image']; ?>"></th>
												<th><?php echo $qry1['Price']; ?></th>
												<th><a href="Update.php?uid=<?php echo $qry1['S_id'];?>" >UPDATE</a> || 
												<a href="delete.php?id=<?php echo $qry1['S_id'];?>" >DELETE</a></th>
											</tr>
											<?php } ?>
											</table>
										</form></center>
                                            </div>
                                        </div></article>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
<?php
include("footer.php");
?>