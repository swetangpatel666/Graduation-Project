<?php
include("header.php");
if(isset($_POST['submit']))
{
	
$qry=mysqli_query($con,"insert into package values(null,'".$_POST['Package_name']."','".$_POST['service']."','".$_POST['Description']."','".$_POST['Price']."')");

}
?>
<section id="content">
                <div class="main zerogrid">
                    <div class="col-full">
                        <div class="row" style="margin: 30px 0;">
                           
                           
                        </div>
                        <div class="container-bot">
                            <div class="container-top">
                                <div class="container">
                                    <div class="wrapper">
                                        <article class="col-2-3"><div class="wrap-col">
                                            <div class="indent-left">
                                                <h3 class="p1">Packages </h3>
                                                <form id="contact-form" method="post" enctype="multipart/form-data">                    
                                                    <fieldset>
                                            <tr>             
									<td><label><span class="text-form">Packages:</span>
									<select name="Package_name"  style="width:343px;padding:3px;">
									<option value="basic" name="Basic">Basic</option>
									<option value="premium" name="Premium">Premium</option>
									<option value="elite" name="Elite">Elite</option>
									</select>
									</label>
									<label style="height:40px;"><span class="text-form">Service:</span>
									<select name="service" multiple >
									<option value=""  style="width:343px;">Select Services</option>
									<?php
									$q=mysqli_query($con,"select * from services");
									while($q1=mysqli_fetch_array($q)){
									
									?>
									<option value="<?php echo $q1['S_id'];?>"><?php echo $q1['S_name'];?></option>
									<?php } ?>
									</select>
									</label>
									<br>
									
									<label><span class="text-form">Description:</span><input name="Description"  type="text" required /></label>
						  <label><span class="text-form">Price:</span><input name="Price" type="text" /></label></td>
															
											</tr>				
														
														 <div class="wrapper">
                                                            
                                                            <div class="extra-wrap">
															
                                                                <div class="Sign Up"></div>
                                                                <div class="buttons" style="text-align: center;">
																
																<input type="submit" class="button" value="Submit" style="width:100px;background-color:darkTomato;font:dark;" name="submit"/>
																		
																<a href="Viewpkg.php"><u>View Packages Detail</u> </a>
                                                                </div> 
                                                            </div>
                                                          </div>   
																			  
                                                    </fieldset>						
                                                </form>
                                            </div>
                                        </div></article>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>			

<?php
 include("footer.php");
 ?>