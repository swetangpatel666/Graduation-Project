<?php
include("header.php");
//$con=mysqli_connect("localhost","root","","car_services");
$q=mysqli_query($con,"select * from services where S_id='".$_GET['uid']."'");
$q1=mysqli_fetch_array($q);

if(isset($_POST['submit']))
{
	$qry=mysqli_query($con,"update services set S_name='".$_POST['S_name']."' where S_id='".$_GET['uid']."'");
	header("location:Viewdel.php");
}
else
{
	echo"";
}
?>

<section id="content">
                <div class="main zerogrid">
                    <div class="col-full">
                        <div class="row" style="margin: 30px 0;">
                           
                           
                        </div>
                      <div class="container-bot">
                            <div class="container-top">
                                <div class="container">
                                    <div class="wrapper">
                                        <article class="col-2-3"><div class="wrap-col">
                                            <div class="indent-left">
                                                <h3 class="p1">Service  </h3>
                                              <form method="post" action="<?php $_PHP_SELF ?>">
	<fieldset>
                                                        <table align="center" border=1>
                                                         <tr>
														 <td><label><span class="text-form">S_id:</span><input name="S_id" type="Number" value="<?php echo $q1['S_id'];?>" /></label></td>                          
                                                       
														
														<td><label><span class="text-form">Services:</span><input name="S_name" type="text" value="<?php echo $q1['S_name'];?>"/></label></td>  
														<td><label><span class="text-form">Description:</span><input name="Description" type="text" value="<?php echo $q1['Description'];?>"/></label></td>  
														
														<td><label><span class="text-form">Image:</span><input type="file" name="file_img[]" ></label></td>  
														
														
														<td><label><span class="text-form">Price:</span><input name="Price" type="text" value="<?php echo $q1['Price'];?>"/></label></td>  
														</tr>														
														</table>	
														
														
														 <div class="wrapper">
                                                            
                                                            <div class="extra-wrap">
															
                                                           
                                                                <div class="buttons" style="text-align: center;">
																
																<input type="submit" class="button" value="submit" style="width:100px;background-color:orange;" name="submit"/>
																		
                                                                </div> 
                                                            </div>
                                                          </div>   
																			  
                                                    </fieldset>
</form>
                                            </div>
                                        </div></article>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
		
<?php
include("footer.php");
?>

												