<?php
include("header.php");
$con=mysqli_connect("localhost","root","","car_services");
?>
<section id="content">
                <div class="main zerogrid">
                    <div class="col-full">
                        <div class="row" style="margin: 30px 0;">
                           
                           
                        </div>
                        <div class="container-bot">
                            <div class="container-top">
                                <div class="container">
                                    <div class="wrapper">
                                        <article class="col-2-3"><div class="wrap-col">
                                            <div class="indent-left">
                                        <center>        <h3 class="p1">Detail Report</h3>
                                        <form method="post" action="<?php $_PHP_SELF ?>">
											<table style="100%"  cellpadding="2">
														<tr>
														
														<th>Name</th>
														<th>Email</th>
														<th>Suggestion</th>
														
														</tr>
													<?php
														$qry=mysqli_query($con,"select *from feedback");
														while($qry1=mysqli_fetch_assoc($qry)){
													?>
											<tr>
												
												<th><?php echo $qry1['Name']; ?></th>
												<th><?php echo $qry1['Email']; ?></th>
												<th><?php echo $qry1['Suggestion']; ?></th>
												
											</tr>
											<?php } ?>
											</table>
										</form></center>
                                            </div>
                                        </div></article>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
<?php
include("footer.php");
?>