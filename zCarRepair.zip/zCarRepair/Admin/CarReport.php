<?php
include("header.php");
$con=mysqli_connect("localhost","root","","car_services");
?>
<section id="content">
                <div class="main zerogrid">
                    <div class="col-full">
                        <div class="row" style="margin: 30px 0;">
                           
                           
                        </div>
                        <div class="container-bot">
                            <div class="container-top">
                                <div class="container">
                                    <div class="wrapper">
                                        <article class="col-2-3"><div class="wrap-col">
                                            <div class="indent-left">
                                        <center>        <h3 class="p1">Detail Report</h3>
                                        <form method="post" action="<?php $_PHP_SELF ?>">
											<table style="100%"  cellpadding="2">
														<tr>
														<th>Car_no</th>
														<th>Car_model</th>
														<th>Car_company</th>
														<th>Car_image</th>
														
														</tr>
													<?php
														$qry=mysqli_query($con,"select *from car_master");
														while($qry1=mysqli_fetch_assoc($qry)){
													?>
											<tr>
												<th><?php echo $qry1['Car_no']; ?></th>
												<th><?php echo $qry1['Car_model']; ?></th>
												<th><?php echo $qry1['Car_company']; ?></th>
												<th><img src="<?php echo $qry1['Image']; ?>"></th>
												
											</tr>
											<?php } ?>
											</table>
										</form></center>
                                            </div>
                                        </div></article>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
<?php
include("footer.php");
?>