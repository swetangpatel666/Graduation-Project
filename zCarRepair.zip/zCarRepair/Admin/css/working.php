<html><head>
		<title>Service Booking Script by PHPJabbers.com</title>
		<meta http-equiv="Content-type" content="text/html; charset=utf-8">
		<link type="text/css" rel="stylesheet" href="https://demo.phpjabbers.com/1565004407_210/app/web/css/reset.css"><link type="text/css" rel="stylesheet" href="https://demo.phpjabbers.com/1565004407_210/core/third-party/jquery_ui/1.10.4/css/smoothness/jquery-ui.min.css"><link type="text/css" rel="stylesheet" href="https://demo.phpjabbers.com/1565004407_210/core/framework/libs/pj/css/pj-all.css"><link type="text/css" rel="stylesheet" href="https://demo.phpjabbers.com/1565004407_210/app/web/css/admin.css"><link type="text/css" rel="stylesheet" href="https://demo.phpjabbers.com/1565004407_210/core/third-party/timepicker/1.0.0/jquery.ui.timepicker.css"><script src="https://connect.facebook.net/signals/plugins/inferredEvents.js?v=2.9.2" async=""></script><script src="https://connect.facebook.net/signals/config/443946209504641?v=2.9.2&amp;r=stable" async=""></script><script async="" src="//connect.facebook.net/en_US/fbevents.js"></script><script src="https://demo.phpjabbers.com/1565004407_210/core/third-party/jquery/1.11.3/jquery.min.js"></script><script src="https://demo.phpjabbers.com/1565004407_210/core/third-party/jquery_migrate/1.3.0/jquery-migrate.min.js"></script><script src="https://demo.phpjabbers.com/1565004407_210/app/web/js/pjAdminCore.js"></script><script src="https://demo.phpjabbers.com/1565004407_210/core/third-party/jquery_ui/1.10.4/js/jquery-ui.custom.min.js"></script><script src="https://demo.phpjabbers.com/1565004407_210/core/third-party/timepicker/1.0.0/jquery.ui.timepicker.js"></script><script src="https://demo.phpjabbers.com/1565004407_210/core/third-party/validate/1.14.0/jquery.validate.min.js"></script><script src="https://demo.phpjabbers.com/1565004407_210/app/web/js/pjAdminTime.js"></script><script src="https://demo.phpjabbers.com/1565004407_210/index.php?controller=pjAdmin&amp;action=pjActionMessages"></script>		<!--[if gte IE 9]>
  		<style type="text/css">.gradient {filter: none}</style>
		<![endif]-->
	<link type="text/css" rel="stylesheet" href="//demo.phpjabbers.com/popup/css/popup.css?v=1.0.0"><script type="text/javascript" src="//demo.phpjabbers.com/popup/js/popup.js?v=1.0.1"></script></head>
	<body>
		<div id="container">
    		<div id="header">
				<div id="logo">
    				<a href="https://www.phpjabbers.com/service-booking-script/" target="_blank" rel="nofollow">Service Booking Script</a>
					<span>v1.0</span>
    			</div>
			</div>
			
			<div id="middle">
				<div id="leftmenu">
					
<div class="leftmenu-top"></div>
<div class="leftmenu-middle">
	<ul class="menu">
		<li><a href="/1565004407_210/index.php?controller=pjAdmin&amp;action=pjActionIndex" class=""><span class="menu-dashboard">&nbsp;</span>Dashboard</a></li>
		<li><a href="/1565004407_210/index.php?controller=pjAdminBookings&amp;action=pjActionIndex" class=""><span class="menu-bookings">&nbsp;</span>Bookings</a></li>
					<li><a href="/1565004407_210/index.php?controller=pjAdminServices&amp;action=pjActionIndex" class=""><span class="menu-services">&nbsp;</span>Services</a></li>
			<li><a href="/1565004407_210/index.php?controller=pjAdminTime&amp;action=pjActionIndex" class="menu-focus"><span class="menu-time">&nbsp;</span>Working time</a></li>
			<li><a href="/1565004407_210/index.php?controller=pjAdminOptions&amp;action=pjActionIndex" class=""><span class="menu-options">&nbsp;</span>Options</a></li>
			<li><a href="/1565004407_210/index.php?controller=pjAdminUsers&amp;action=pjActionIndex" class=""><span class="menu-users">&nbsp;</span>Users</a></li>
			<li><a href="/1565004407_210/index.php?controller=pjAdminOptions&amp;action=pjActionPreview" class=""><span class="menu-install">&nbsp;</span>Preview &amp; Install</a></li>
					<li><a href="/1565004407_210/index.php?controller=pjAdmin&amp;action=pjActionLogout"><span class="menu-logout">&nbsp;</span>Logout</a></li>
	</ul>
</div>
<div class="leftmenu-bottom"></div>				</div>
				<div id="right">
					<div class="content-top"></div>
					<div class="content-middle" id="content">
						
	<div class="ui-tabs ui-widget ui-widget-content ui-corner-all b10">
		<ul class="ui-tabs-nav ui-helper-reset ui-helper-clearfix ui-widget-header ui-corner-all">
			<li class="ui-state-default ui-corner-top ui-tabs-active ui-state-active"><a href="/1565004407_210/index.php?controller=pjAdminTime&amp;action=pjActionIndex">Default working time</a></li>
			<li class="ui-state-default ui-corner-top"><a href="/1565004407_210/index.php?controller=pjAdminTime&amp;action=pjActionCustom">Custom working time</a></li>
		</ul>
	</div>
			<div class="notice-box">
			<div class="notice-top"></div>
			<div class="notice-middle">
				<span class="notice-info">&nbsp;</span>
				<span class="block bold">Default working time</span><span class="block">Here you can set working time for each day of the week. You can also set days off. </span><a href="#" class="notice-close"></a>			</div>
			<div class="notice-bottom"></div>
		</div>
			<form id="frmDefaultWTime" action="/1565004407_210/index.php?controller=pjAdminTime&amp;action=pjActionIndex" method="post" class="form" novalidate="novalidate">
		<input type="hidden" name="working_time" value="1">
					<input type="hidden" name="id" value="1">
					<table class="pj-table" cellpadding="0" cellspacing="0" style="width: 100%;">
			<thead>
				<tr>
					<th>Day of week</th>
					<th>Is Day off</th>
					<th>Start time</th>
					<th>End time</th>
				</tr>
			</thead>
			<tbody>
							<tr class="odd" data-day="monday">
					<td>Monday</td>
					<td class="align_center"><input type="checkbox" class="working_day" name="monday_dayoff" value="T"></td>
					<td>
						<p class="w130 tsWorkingDay_monday">
							<span class="inline-block">
								<input name="monday_from" data-day="monday" value="09:00" class="pj-timepicker pj-form-field w80" readonly="readonly">
							</span>
						</p>
					</td>
					<td>
						<p class="w130 tsWorkingDay_monday">
							<span class="inline-block">
								<input name="monday_to" data-day="monday" value="19:00" class="pj-timepicker pj-form-field w80" readonly="readonly">								
							</span>
						</p>
					</td>
				</tr>
								<tr class="even" data-day="tuesday">
					<td>Tuesday</td>
					<td class="align_center"><input type="checkbox" class="working_day" name="tuesday_dayoff" value="T"></td>
					<td>
						<p class="w130 tsWorkingDay_tuesday">
							<span class="inline-block">
								<input name="tuesday_from" data-day="tuesday" value="09:00" class="pj-timepicker pj-form-field w80" readonly="readonly">
							</span>
						</p>
					</td>
					<td>
						<p class="w130 tsWorkingDay_tuesday">
							<span class="inline-block">
								<input name="tuesday_to" data-day="tuesday" value="19:00" class="pj-timepicker pj-form-field w80" readonly="readonly">								
							</span>
						</p>
					</td>
				</tr>
								<tr class="odd" data-day="wednesday">
					<td>Wednesday</td>
					<td class="align_center"><input type="checkbox" class="working_day" name="wednesday_dayoff" value="T"></td>
					<td>
						<p class="w130 tsWorkingDay_wednesday">
							<span class="inline-block">
								<input name="wednesday_from" data-day="wednesday" value="09:00" class="pj-timepicker pj-form-field w80" readonly="readonly">
							</span>
						</p>
					</td>
					<td>
						<p class="w130 tsWorkingDay_wednesday">
							<span class="inline-block">
								<input name="wednesday_to" data-day="wednesday" value="19:00" class="pj-timepicker pj-form-field w80" readonly="readonly">								
							</span>
						</p>
					</td>
				</tr>
								<tr class="even" data-day="thursday">
					<td>Thursday</td>
					<td class="align_center"><input type="checkbox" class="working_day" name="thursday_dayoff" value="T"></td>
					<td>
						<p class="w130 tsWorkingDay_thursday">
							<span class="inline-block">
								<input name="thursday_from" data-day="thursday" value="09:00" class="pj-timepicker pj-form-field w80" readonly="readonly">
							</span>
						</p>
					</td>
					<td>
						<p class="w130 tsWorkingDay_thursday">
							<span class="inline-block">
								<input name="thursday_to" data-day="thursday" value="19:00" class="pj-timepicker pj-form-field w80" readonly="readonly">								
							</span>
						</p>
					</td>
				</tr>
								<tr class="odd" data-day="friday">
					<td>Friday</td>
					<td class="align_center"><input type="checkbox" class="working_day" name="friday_dayoff" value="T"></td>
					<td>
						<p class="w130 tsWorkingDay_friday">
							<span class="inline-block">
								<input name="friday_from" data-day="friday" value="09:00" class="pj-timepicker pj-form-field w80" readonly="readonly">
							</span>
						</p>
					</td>
					<td>
						<p class="w130 tsWorkingDay_friday">
							<span class="inline-block">
								<input name="friday_to" data-day="friday" value="19:00" class="pj-timepicker pj-form-field w80" readonly="readonly">								
							</span>
						</p>
					</td>
				</tr>
								<tr class="even" data-day="saturday">
					<td>Saturday</td>
					<td class="align_center"><input type="checkbox" class="working_day" name="saturday_dayoff" value="T"></td>
					<td>
						<p class="w130 tsWorkingDay_saturday">
							<span class="inline-block">
								<input name="saturday_from" data-day="saturday" value="10:00" class="pj-timepicker pj-form-field w80" readonly="readonly">
							</span>
						</p>
					</td>
					<td>
						<p class="w130 tsWorkingDay_saturday">
							<span class="inline-block">
								<input name="saturday_to" data-day="saturday" value="20:00" class="pj-timepicker pj-form-field w80" readonly="readonly">								
							</span>
						</p>
					</td>
				</tr>
								<tr class="odd" data-day="sunday">
					<td>Sunday</td>
					<td class="align_center"><input type="checkbox" class="working_day" name="sunday_dayoff" value="T"></td>
					<td>
						<p class="w130 tsWorkingDay_sunday">
							<span class="inline-block">
								<input name="sunday_from" data-day="sunday" value="10:00" class="pj-timepicker pj-form-field w80" readonly="readonly">
							</span>
						</p>
					</td>
					<td>
						<p class="w130 tsWorkingDay_sunday">
							<span class="inline-block">
								<input name="sunday_to" data-day="sunday" value="20:00" class="pj-timepicker pj-form-field w80" readonly="readonly">								
							</span>
						</p>
					</td>
				</tr>
							</tbody>
			<tfoot>
				<tr>
					<td colspan="6"><input type="submit" value="Save" class="pj-button"></td>
				</tr>
			</tfoot>
		</table>
	</form>
	<script type="text/javascript">
	var myLabel = myLabel || {};
	myLabel.showperiod = false;
	</script>
						</div>
					<div class="content-bottom"></div>
				</div> <!-- content -->
				<div class="clear_both"></div>
			</div> <!-- middle -->
		
		</div> <!-- container -->
		<div id="footer-wrap">
			<div id="footer">
			   	<p>Copyright © 2019 <a href="https://www.PHPJabbers.com" target="_blank">PHPJabbers.com</a></p>
	        </div>
        </div>
	<script async="" src="//demo.phpjabbers.com/popup/js/load.js"></script>
	<div class="pjd-popup pjd-popup-ask-question">
		<div class="pjd-popup-head">
			<a href="https://www.phpjabbers.com/team.php#sectionTeamSupport" target="_blank" class="pjd-popup-support">
				<div class="pjd-popup-support-image"><img src="https://demo.phpjabbers.com/popup/css/images/pjd-popup-support-image-1.png" alt="Kosta"></div>
				<div class="pjd-popup-support-name">Kosta</div>
				<div class="pjd-popup-support-status">last active 20 minutes ago</div>
			</a>
		</div>
	
		<div class="pjd-popup-body">
			<div class="pjd-popup-body-inner">
				<p>Hi,</p>
									<p class="pjd-popup-extended">Your private demo installation will be available for the next 4 hours. You can extend it to a <strong>1-week FREE trial</strong> using <a href="#" class="pjd-popup-extend-trigger" data-name="is_extended">this link</a>.</p>
										<p class="pjd-popup-unbranded">If you are a webmaster and need to <strong>remove PHPJabbers branding</strong> to show our product to your clients, just <a href="#" class="pjd-popup-extend-trigger" data-name="is_unbranded">click here</a>.</p>
										
				<p>Do not hesitate to contact us if you have any questions!</p>
				<p><em>Regards,<br>Kosta @ PHPJabbers.com</em></p>
			</div>
		</div>
	
		<div class="pjd-popup-footer">
					<a target="_blank" href="https://www.phpjabbers.com/contact.php" class="pjd-popup-form-trigger">Ask a question</a>
						<a href="https://www.phpjabbers.com/ticket/{TicketID}" target="_blank" class="pjd-popup-open-support-ticket">Open Support Ticket</a>
		</div>
	</div>
			<div class="pjd-popup pjd-popup-extend">
			<div class="pjd-popup-head">
				<div class="pjd-popup-heading">
				Extend &amp; Unbrand				
				</div>
			</div>
		
			<div class="pjd-popup-body">
				<div class="pjd-popup-form">
					<form action="" method="post" id="pjd-popup-extend-form">
						<input type="hidden" name="do_extend" value="1">
						<input type="hidden" name="ticket_uuid" value="">
						<div class="pjd-popup-radio-holder">
													<label class="pjd-popup-radio">
								<input type="checkbox" name="is_extended" value="1" class="pjd-popup-checkbox">
								Extend trial for 1 week
							</label>
														<label class="pjd-popup-radio">
								<input type="checkbox" name="is_unbranded" value="1" class="pjd-popup-checkbox">
								Remove PHPJabbers branding
							</label>
													</div>
				
						<p>Fill in the form below to receive instructions how to extend the trial installation and/or remove our branding.</p>
						<input type="text" name="name" class="pjd-popup-field" placeholder="Your Name" maxlength="255" value="">
						<input type="email" name="email" class="pjd-popup-field" placeholder="Email address" maxlength="255" value="">
						<div class="pjd-popup-form-actions">
							<button type="submit" class="pjd-btn-primary">Extend</button>
							<a href="#" class="pjd-popup-extend-cancel">Cancel</a>
						</div>
					</form>
				</div>
			</div>
		</div>
			<a href="https://www.phpjabbers.com/mega-sale.php?ref=d-sbsc" class="pjd-mega-sale-button pjd-mega-sale-trigger" target="_blank">Special Offer</a>
	<a href="#" class="pjd-popup-trigger">Ask a question</a>
	</body></html>