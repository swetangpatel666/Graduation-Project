<?php
include("cheader.php");
?>
                </div>
            </header>
            
            <!--==============================content================================-->
            <section id="content">
                <div class="main zerogrid">
                    <div class="col-full">
                       
                        <div class="container-bot">
                            <div class="container-top">
                                <div class="container">
                                    <div class="wrapper">
                                        <article class="col-2-3"><div class="wrap-col">
                                            <div>
											<?php
											$q=mysqli_query($con,"select * from services where S_id='".$_GET['id']."'");
											while($q1=mysqli_fetch_array($q)) {
											?>
                                                <h3><font color="Tomato"><?php echo $q1['S_name']; ?></font></h3>
                                                <div class="wrapper margin-bot">
													<div class="col-1-3">
                                                    <figure class="img-indent3"><img src="admin/<?php echo $q1['Image'];?>" alt=""></figure>
													</div>
                                                    <div class="col-2-3 extra-wrap">
                                                        <h6><strong>CR Price :<?php  echo 'Rs. '.$q1['Price'];?> </strong></h6>
                                                        <p><?php echo $q1['Description'];?></p>
														<?php 
														if(isset($_SESSION['un']))
														{
														
														?>
                                                        <a class="button" href="booked.php">Book</a>
														
														<?php } ?>
                                                    </div>
                                                </div>
                                             <?php } ?>  
                                            </div>
                                        </div></article>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            
            <!--==============================footer=================================-->
           <?php
		   
		   include("cfooter.php");
		   ?>