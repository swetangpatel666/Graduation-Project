<?php
include("cheader.php");
//$con=mysqli_connect("localhost","root","","car_services");
if(isset($_POST['submit']))
{
$qry=mysqli_query($con,"insert into feedback values('".$_POST['Name']."',null,'".$_POST['Email']."','".$_POST['Suggestion']."')");
echo "Detail Inserted Successfully";
}
else
{
echo "Something Wrong";
}
?>

<section id="content">
                <div class="main zerogrid">
                    <div class="col-full">
                        <div class="row" style="margin: 30px 0;">
                           
                           
                        </div>
                        <div class="container-bot">
                            <div class="container-top">
                                <div class="container">
                                    <div class="wrapper">
                                        <article class="col-2-3"><div class="wrap-col">
                                            <div class="indent-left">
                                                <h3 class="p1">Give Your HelpFull Feedback Here</h3>
                                               <form id="contact-form" method="post" enctype="multipart/form-data">                    
                                                    <fieldset>
															
                                                          <label><span class="text-form">Name:</span><input name="Name" type="text" /></label>
                                                          <label><span class="text-form">Email:</span><input name="Email" type="text" /></label>                              
                                       
                                                         <label><span class="text-form">Suggestion:</span><textarea  name="Suggestion"  style="width:325px;"> </textarea></label>
                                                             
                                                                <div class="extra-wrap">
															
                                                                <div class="Sign Up"></div>
                                                                <div class="buttons" style="text-align: center;">
																
																<input type="submit" class="button" value="Submit" style="width:100px;background-color:orange;" name="submit"/>


															   
                                                            </div>
                                                          </div>                            
                                                    </fieldset>						
                                                </form><br><br><br><br><br>
												<h3>FeedBack</h3>
												                                       
											<table style="100%"  cellpadding="2">
														
													<?php
														$qry=mysqli_query($con,"select *from feedback");
														while($qry1=mysqli_fetch_assoc($qry)){
													?>
											<tr>
												<?php echo $qry1['Suggestion']; ?>
												<td><?php echo $qry1['Name']; ?></td>
												
											</tr>
											<?php } ?>
											</table>
										
                                            </div>
                                        </div></article>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
				
            </section>					
<?php
 include("cfooter.php");
?>