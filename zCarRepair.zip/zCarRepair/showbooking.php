<?php
include("cheader.php");
$owid=session_id();
$email=$_SESSION['un'];
if(isset($_POST['submit']))
{
	$sqry=mysqli_query($con,"update booking_services set confirm='yes' where Email='".$_SESSION['un']."' ");
	header("location:bill.php");
}
 
?>
                </div>
            </header>
            
            <!--==============================content================================-->
            <section id="content">
                <div class="main zerogrid">
                    <div class="col-full">
                    
                        <div class="container-bot">
                            <div class="container-top">
                                <div class="container">
                                    <div class="wrapper">
                                        <article class="col-2-3"><div class="wrap-col">
                                            <div class="indent-left">
                                                <h3 class="p1">Booking Details:</h3>
                                                <form  method="post" enctype="multipart/form-data">                    
                                                    <fieldset>
                                                       <table  class="table table-bordered">
													   <thead>
														<tr>
														<th><h4>Booking Id</h4></th>
															<th><h4>Car number</h4></th>
															<th><h4>Car model</h4></th>
															<th><h4>Company</h4></th>
															<th><h4>Image</h4></th>
															<th><h4>Service</h4></th>
															<th><h4>Packages</h4></th>
															<th><h4>Date</h4></th>
															<th><h4>Remove</h4></th>
															
													   
														</tr>
														 </thead>
														<tbody>
														<?php
														$q=mysqli_query($con,"select * from car_master c,services s,booking_services b,
														where c.Email=b.Email and s.S_id=b.S_id   and  b.Email='".$_SESSION['un']."'
														and b.confirm='no' group by c.Car_no");
														while($q1=mysqli_fetch_array($q)){
														?>
														<tr>
														<td><b><?php echo $q1['owner_id']; ?></b></td>
														<td><b><?php echo $q1['Car_no']; ?></b></td>
														<td><b><?php echo $q1['Car_model']; ?></b></td>
														<td><b><?php echo $q1['Car_company']; ?></b></td>
														<td><b><img src="<?php echo $q1['Car_image']; ?>"></b></td>
														<td><b><?php echo $q1['S_name']; ?></b></td>
														<td><b><?php echo $q1['package_id']; ?></b></td>
														<td><b><?php echo $q1['Date']; ?></b></td>
														<td><a href="delete.php?oid=<?php echo $q1['Booking_id']; ?>"><b>Remove</b></a></td>
														</tr>
														<?php } ?>
														</tbody>
														</table>
														 <div class="wrapper">
                                                           
                                                            <div class="extra-wrap">
                                                        
                                                                <div class="buttons" style="text-align: center;">
																  <input type="submit" name="submit" value="Book Now" style="bgcolor:black">
	
	
                                                                  
                                                                </div> 
                                                            </div>
                                                          </div>     
                                                    </fieldset>						
                                                </form>
                                            </div>
                                        </div></article>
                                
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            
            <!--==============================footer=================================-->
             <?php
		   
		   include("cfooter.php");
		   ?>