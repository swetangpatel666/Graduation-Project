<?php
include("cheader.php");
?>
<style>
table ,th,th
{
	border:2px solid grey;
}
</style>
<section id="content">
                <div class="main zerogrid">
                    <div class="col-full">
                        <div class="row" style="margin: 30px 0;">
                           
                           
                        </div>
                        <div class="container-bot">
                            <div class="container-top">
                                <div class="container">
                                    <div class="wrapper">
                                        <article class="col-2-3"><div class="wrap-col">
                                            <div class="indent-left">
                    <center>        <h3 class="p1">Bill</h3>              
                    <div style="width:500px;height:500px;margin:auto;">
					<table border="1" cellspacing="0" style="100%;">
													<?php
														$qry=mysqli_query($con,"select *from booking_services");
														while($qry1=mysqli_fetch_assoc($qry)){
													?>
	
						<tr>
								<th colspan="10" style="width:420px;">Shop Name:</th>
								<th colspan="10" style="width:420px;">Date:</th>
		 
						</tr>
						<tr>
								<th colspan="20">Bill No.:</th>
						</tr>
						<tr>
								<th colspan="20">Name:</th>
						</tr>
						<tr>
								<th colspan="5">Sr.No</th>
								<th colspan="5">Prticulars</th>
								<th colspan="5">Qty</th>
								<th colspan="5">Amount</th>
						</tr>
						<tr>
								<th colspan="5">1</th><th colspan="5">Booking Id</th><th colspan="5"><?php echo $qry1['Booking_id']; ?></th><th colspan="5"></th>
						</tr>
						<tr>
								<th colspan="5">2</th><th colspan="5">Service Id</th><th colspan="5"><?php echo $qry1['S_id']; ?></th><th colspan="5"></th>	
						</tr>
						<tr>
								<th colspan="5">3 </th><th colspan="5">Packages</th><th colspan="5"></th><th colspan="5"></th>
						</tr>
						<tr>
								<th colspan="5">4</th><th colspan="5">Car No.</th><th colspan="5"><?php echo $qry1['Car_no']; ?></th><th colspan="5"></th>
						</tr>
						<tr>
								<th colspan="13"></th><th colspan="7">Price:</th>
						</tr>
						<?php } ?>
					</table>
					</div>
                    </center>          
					</div>
                                        </div></article>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

<?php
include("cfooter.php");
?>