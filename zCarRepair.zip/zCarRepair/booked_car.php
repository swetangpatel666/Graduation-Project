<?php
include("cheader.php");
$owid=session_id();
$email=$_SESSION['un'];
if(isset($_POST['submit']))
{
	$sqry=mysqli_query($con,"update booking_services set confirm='yes' where Email='".$_SESSION['un']."' ");
	
	header("location:bill.php");
}
 
?>
                </div>
            </header>
            
            <!--==============================content================================-->
            <section id="content">
                <div class="main zerogrid">
                    <div class="col-full">
                    
                        <div class="container-bot">
                            <div class="container-top">
                                <div class="container">
                                    <div class="wrapper">
                                        <article class="col-2-3"><div class="wrap-col">
                                            <div class="indent-left">
                                                <h3 class="p1">Booking Details:</h3>
                                                <form  method="post" enctype="multipart/form-data">                    
                                                    <fieldset>
                                                       <table  class="table table-bordered">
													   <thead>
														<tr>
														
															<th><h4>Car number</h4></th>
															<th><h4>Car model</h4></th>
															<th><h4>Company</h4></th>
															<th><h4>Image</h4></th>
															
															<th><h4>Book</h4></th>
															
													   
														</tr>
														 </thead>
    <tbody>
														<?php
														$q=mysqli_query($con,"select * from car_master where Email='".$_SESSION['un']." '");
														while($q1=mysqli_fetch_array($q)){
														?>
														<tr>
														
														<td><b><?php echo $q1['Car_no']; ?></b></td>
														<td><b><?php echo $q1['Car_model']; ?></b></td>
														<td><b><?php echo $q1['Car_company']; ?></b></td>
														<td><b><?php echo $q1['Car_image']; ?></b></td>
														
														<td><a href="book_service.php?oid=<?php echo $q1['Email']; ?>"><b>Book Service</b></a></td>
														</tr>
														<?php } ?>
														</tbody>
														</table>
														 <div class="wrapper">
                                                           
                                                            <div class="extra-wrap">
                                                        
                                                                <div class="buttons" style="text-align: center;">
																  <input type="submit" name="submit" value="Book Now" style="display:inline-block; 
	margin-right:16px;
	width:100px;
	font-size:13px;
	line-height:1.23em;
	font-weight:bold;
	color:#000; 
	background:url(../images/button-tail.gif) 0 0 repeat-x #fb4400;
	cursor:pointer;
	border-radius:3px;
	-moz-border-radius:3px;
	-webkit-border-radius:3px;">
	
	
                                                                  
                                                                </div> 
                                                            </div>
                                                          </div>     
                                                    </fieldset>						
                                                </form>
                                            </div>
                                        </div></article>
                                
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            
            <!--==============================footer=================================-->
             <?php
		   
		   include("cfooter.php");
		   ?>