 <footer>
 
                <div class="main zerogrid">
                    <span>Car Repair &copy; 2014</span>
                    Designed by <a href="http://www.TemplateMonster.com" target="_blank" rel="nofollow">TemplateMonster</a> | <a href="https://www.zerotheme.com" title="free website templates">ZEROTHEME</a>
                </div>
            </footer>
        </div>
    </div>
	<script type="text/javascript"> Cufon.now(); </script>
</body>
</html>