<?php
include("cheader.php");
$owid=session_id();
if(isset($_POST['submit']))
{
	for($i=0;$i<count($_FILES['file_img']['name']);$i++)
	{
		$filetemp=$_FILES["file_img"]["tmp_name"][$i];
		$filename=$_FILES["file_img"]["name"][$i];
		$filetype=$_FILES["file_img"]["type"][$i];
		
		$filepath="".$filename;
		move_uploaded_file($filetemp,$filepath);
		$qry=mysqli_query($con,"insert into car_master values('".$_SESSION['un']."','".$_POST['cno']."','".$_POST['model']."','".$_POST['company']."'
,'$filepath')");
$result=mysqli_query($con,$qry);
		echo "<script type='text/javascript'>" ;
		echo "alert('Successfully registerd your car!..now fill service detail ....');";
		echo "window.location.href='book_service.php';";
		echo "</script>";
		}	
}

?>
                </div>
            </header>
            
            <!--==============================content================================-->
            <section id="content">
                <div class="main zerogrid">
                    <div class="col-full">
                    
                        <div class="container-bot">
                            <div class="container-top">
                                <div class="container">
                                    <div class="wrapper">
                                        <article class="col-2-3"><div class="wrap-col">
                                            <div class="indent-left">
                                                <h3 class="p1">Give Your Car Details...</h3>
                                                <form  method="post" enctype="multipart/form-data">                    
                                                    <fieldset>
                                                          <table>
														  <tr>
														  <td>
                                                          <label><strong>Car Number:</strong></td><td><input name="cno" type="text" style="width:100%;"  /></label></td>
														 
														  </tr>
													  
                                                          <tr>
														  <td> <label><strong>Car Model:</strong></td><td><input name="model" type="text" style="width:100%;" /></label></td></tr>
													<tr>
														  <td><label><strong>Car Company:</strong></td><td><input name="company" type="text" style="width:100%;" /></label> </td></tr>                                 
                                                         <tr>
														  <td> <label><strong>Car Image:</strong></td><td><input type="file" name="file_img[]" style="width:100%;" /></label> </td></tr>                                
                                                         	</table>													   
                                                          <div class="wrapper">
                                                           
                                                            <div class="extra-wrap">
                                                         
															  
															  
                                                                <div class="buttons" style="text-align: center;">
																  <input type="submit" name="submit"style="display:inline-block; 
	margin-right:16px;
	width:100px;
	font-size:13px;
	line-height:1.23em;
	font-weight:bold;
	color:#000; 
	background:url(../images/button-tail.gif) 0 0 repeat-x #fb4400;
	cursor:pointer;
	border-radius:3px;
	-moz-border-radius:3px;
	-webkit-border-radius:3px;">
	<input type="reset" name="reset"style="display:inline-block; 
	
	width:100px;
	font-size:13px;
	line-height:1.23em;
	font-weight:bold;
	color:#000; 
	background:url(../images/button-tail.gif) 0 0 repeat-x #fb4400;
	cursor:pointer;
	border-radius:3px;
	-moz-border-radius:3px;
	-webkit-border-radius:3px;">
	<br/>
	
                                                                  
                                                                </div> 
                                                            </div>
                                                          </div>                            
                                                    </fieldset>						
                                                </form>
                                            </div>
                                        </div></article>
                                
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            
            <!--==============================footer=================================-->
             <?php
		   
		   include("cfooter.php");
		   ?>