<?php
include("cheader.php");
$owid=session_id();
$email=$_SESSION['un'];
 if (isset($_POST['submit']))
{
	
	$check2 = $_POST['check2'];
	$cb="";
	if(!empty($check2))
	{
		foreach($check2 as $cn2)
		{
			$cb.=$cn2.",";
		}

$qry=mysqli_query($con,"insert into booking_services values(null,'".$owid."',
'".$email."',null,'".$cb."','".date('y-m-d')."','no')");

echo "<script type='text/javascript'>" ;
			echo "alert('Successfull');";
		echo "window.location.href='showbooking.php';";
			echo "</script>";
			

}
else
{
	echo 'hfgfj';
}
}
?>

                </div>
            </header>
    
            <!--==============================content================================-->
            <section id="content">
                <div class="main zerogrid">
                    <div class="col-full">
                    
                        <div class="container-bot">
                            <div class="container-top">
                                <div class="container">
                                    <div class="wrapper">
                                        <article class="col-2-3"><div class="wrap-col">
                                            <div class="indent-left">
                                                <h3 class="p1">Select Package:</h3>
                                                <form  method="post" enctype="multipart/form-data">                    
                                                    <fieldset>
                                                  	<ul>  

													<?php
														 $q=mysqli_query($con,"select * from package");
														 while($q1=mysqli_fetch_array($q)){
														  ?>
														<input type="checkbox" name="check2[]" value="<?php echo $q1['package_id'];?>"><?php echo $q1['Package_name'];?></br>
													<?php } ?>
														
														
														  	</ul>												   
                                                          <div class="wrapper">
                                                           
                                                            <div class="extra-wrap">
                                                        
                                                                <div class="buttons" style="text-align: center;">
																  <input type="submit" name="submit"style="display:inline-block; 
	margin-right:16px;
	width:100px;
	font-size:13px;
	line-height:1.23em;
	font-weight:bold;
	color:#000; 
	background:url(../images/button-tail.gif) 0 0 repeat-x #fb4400;
	cursor:pointer;
	border-radius:3px;
	-moz-border-radius:3px;
	-webkit-border-radius:3px;">
	<input type="reset" name="reset"style="display:inline-block; 
	
	width:100px;
	font-size:13px;
	line-height:1.23em;
	font-weight:bold;
	color:#000; 
	background:url(../images/button-tail.gif) 0 0 repeat-x #fb4400;
	cursor:pointer;
	border-radius:3px;
	-moz-border-radius:3px;
	-webkit-border-radius:3px;">
	<br/>
	
                                                                  
                                                                </div> 
                                                            </div>
                                                          </div>                            
                                                    </fieldset>						
                                                </form>
                                            </div>
                                        </div></article>
                                
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            
            <!--==============================footer=================================-->
<?php
include("cfooter.php");
?>