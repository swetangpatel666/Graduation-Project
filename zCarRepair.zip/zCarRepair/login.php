<?php
include("cheader.php");
                                                     
 if (isset($_POST['submit']))
{
	$rm=mysqli_query($con,"select * from customer where Email='".$_POST['email']."' and Password='".$_POST['password']."'");
	   echo mysqli_error($con);
	if($q=mysqli_num_rows($rm)>0)
	{
		$_SESSION['un']=$_POST['email'];
		
			echo "<script type='text/javascript'>" ;
			echo "alert('Customer Login Successfully');";
			echo "window.location.href='index.php';";
			echo "</script>";
			
	}
	else
	{
		
		echo "<script type='text/javascript'>";
		echo "alert('Email or Password is incorrect!');";
		echo "</script>";
	    
	}
}	
	?>

                </div>
            </header>
            
            <!--==============================content================================-->
            <section id="content">
                <div class="main zerogrid">
                    <div class="col-full">
                    
                        <div class="container-bot">
                            <div class="container-top">
                                <div class="container">
                                    <div class="wrapper">
                                        <article class="col-2-3"><div class="wrap-col">
                                            <div class="indent-left">
                                                <h3 class="p1">USER LOGIN</h3>
                                                <form id="contact-form" method="post" enctype="multipart/form-data">                    
                                                    <fieldset>
                                                          
                                                          <label><span class="text-form">Email:</span><input name="email" type="text" /></label>                              
                                                          <label><span class="text-form">Password:</span><input name="password" type="password" /></label>                              
                                                          <div class="wrapper">
                                                           
                                                            <div class="extra-wrap">
     
															  
															  
															  
															  
                                                              
																  <input type="submit" name="submit"style="display:inline-block; 
	margin-right:16px;
	width:100px;
	font-size:13px;
	line-height:1.23em;
	font-weight:bold;
	color:#000; 
	background:url(../images/button-tail.gif) 0 0 repeat-x #fb4400;
	cursor:pointer;
	border-radius:3px;
	-moz-border-radius:3px;
	-webkit-border-radius:3px;">
	<input type="reset" name="reset"style="display:inline-block; 
	
	width:100px;
	font-size:13px;
	line-height:1.23em;
	font-weight:bold;
	color:#000; 
	background:url(../images/button-tail.gif) 0 0 repeat-x #fb4400;
	cursor:pointer;
	border-radius:3px;
	-moz-border-radius:3px;
	-webkit-border-radius:3px;">
	<br/>
	
                                                                  
                                                              
																<h4>New User ?<font color="red" size="medium"><a href="register.php">Click here....</a></font></h4>
                                                            </div>
                                                          </div>                            
                                                    </fieldset>						
                                                </form>
                                            </div>
                                        </div></article>
                                
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            
            <!--==============================footer=================================-->
             <?php
		   
		   include("cfooter.php");
		   ?>