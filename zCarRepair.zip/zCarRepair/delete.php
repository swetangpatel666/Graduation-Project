<?php
$con=mysqli_connect("localhost","root","","car_services");
session_start();
if($_GET['oid'])
{
	$q=mysqli_query($con,"delete from booking_services where Booking_id='".$_GET['oid']."' ");
	header("location:showbooking.php");  
	
}
?>