<?php

include("cheader.php");

?>
                    <div class="slider zerogrid">
						<div class="rslides_container">
							<ul class="rslides" id="slider">
								<li><img src="images/slider-img1.jpg" alt="" /></li>
								<li><img src="images/slider-img2.jpg" alt="" /></li>
								<li><img src="images/slider-img3.jpg" alt="" /></li>
							</ul>
						</div>
                    </div>
                </div>
            </header>
            
            <!--==============================content================================-->
            <section id="content">
                <div class="main zerogrid">
                    <div class="col-full">
                        <div class="row" style="margin: 30px 0;">
                            <article class="col-1-3">
                                <div class="wrap-col">
                                    <figure class="img-indent"><img src="images/homep-6.png" alt=""></figure>
                                    <div class="extra-wrap">
                                        <h4>Fill Form</h4>
                                        <p class="p2">
										Fill the enquiry formwith all your relevantdetails</p>
                                        
                                    </div>
                                </div>
                            </article>
                            <article class="col-1-3">
                                <div class="wrap-col">
                                    <figure class="img-indent"><img src="images/homep-7.png" alt=""></figure>
                                    <div class="extra-wrap">
                                        <h4>BOOK AN APPOINTMENT</h4>
                                        <p class="p2">Provide your home or office location. Tell us when to meet you there.</p>
                                       
                                    </div>
                                </div>
                            </article>
                            <article class="col-1-3">
                                <div class="wrap-col">
                                    <figure class="img-indent"><img src="images/homep-8.png" alt=""></figure>
                                    <div class="extra-wrap">
                                        <h4>GET YOUR CAR FIXED</h4>
                                        <p class="p2">That's it. No more waiting in repair shops - our mechanics come to you.</p>
                                       
                                    </div>
                                </div>
                            </article>
                        </div>
                        <div class="container-bot">
                            <div class="container-top">
                                <div class="container">
                                    <div class="row">
                                        <article class="col-2-3"><div class="wrap-col">
                                            <div class="indent-left">
                                                <h2>Welcome!
												<font color="Tomato"><?php
												if(isset($_SESSION['un']))
												{
													$qry=mysqli_query($con,"select * from customer where Email='".$_SESSION['un']."'");
												$qry1=mysqli_fetch_array($qry);
												echo $qry1['Name'];
												}
												else
												{
												echo '';
												}
												?>
												
												
												
												</font></h2>
                                                <p class="border-bot"><strong>Car Repair</strong>  is India's first standardized network of workshops to provide car services.
												We provide affordable, transparent and convenient on-demand car services at the comfort of your home or your office.
												With expert mechanics, state-of-the-art machinery, top quality spares, standardized processes & pricing, <strong>Car Repair</strong> provides a uniform service experience to all its customers, across its workshops. 
												Everything under one-roof : servicing, repairs, inspections, denting/painting, roadside assistance and car care.</p>
                                            </div>
                                            <div class="wrapper">
                                                <div class="col-1-2"><div style="margin-right: 30px;">
                                                   
                                                </div></div>
												<div class="col-1-2"><div style="text-decoration:silver;">
															<div class="indent-left">
															<div class="indent-bot">
                                                            <h3 class="p0">Our Packages</h3>
															<ul class="list-1">
															<?php
															$q=mysqli_query($con,"select * from package");
															while($q1=mysqli_fetch_array($q))
															{
															?>
                                                                <li><a href="#"><?php  echo $q1['Package_name'];?></a></li>
                                                                
															<?php } ?>
															</ul>
															</div>
                                                        <a class="button" href="detailpkg.php">Read More</a>
                                                    </div>
                                                </div></div>
                                                <div class="col-1-2">
                                                    <div class="indent-left">
                                                        <div class="indent-bot">
                                                            <h3 class="p0">Our Services</h3>
                                                            <ul class="list-1">
															<li>
															<?php
															$q=mysqli_query($con,"select * from services limit 5");
															while($q1=mysqli_fetch_array($q))
															{
															?>
                                                                <li><a href="#"><?php  echo $q1['S_name'];?></a></li>
                                                                
															<?php } ?>
															
															</ul>
                                                        </div>
                                                        <a class="button" href="services.php">Read More</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div></article>
                                        <article class="col-1-3"><div class="wrap-col">
                                            <div class="indent-left2 indent-top">
                                                <div class="box p4">
                                                    <div class="padding">
                                                        <div class="wrapper">
                                                            
                                                            <div class="extra-wrap">
                                                               <center> <h3 class="p0">Registered Users:</h3></center>
                                                           
                                                        <?php $q=mysqli_query($con,"select count(*) As Email from customer");
														$m1=mysqli_fetch_array($q);
														$a=$m1['Email'];
														echo "<center><h3> $a </h3></center>";
														?>
														 </div>
                                                        </div>
                                                    </div>
                                                </div>
												<div class="box p4">
                                                    <div class="padding">
                                                        <div class="wrapper">
                                                            <figure class="img-indent"><img src="images/page1-img4.png" alt=""></figure>
                                                            <div class="extra-wrap">
                                                                <h3 class="p0">Our Hours:</h3>
                                                            </div>
                                                        </div>
                                                        <p class="p1"><strong>24 Hour Emergency Towing</strong></p>
                                                        <p class="color-1 p0">Monday - Friday: 7:30 am - 6:00</p>
                                                        <p class="color-1 p1">Saturday: 7:30 am - Noon</p>
                                                        Night Drop Available
                                                    </div>
                                                </div>
                                               
                                                <div class="indent-left">
                                                    <dl class="main-address">
                                                        <dt>Valsad,Tithal Road,<br> Glasgow, D04 89GR.</dt>
                                                        <dd><span>phone:</span>959 552 5963;</dd>
                                                        
                                                        <dd><span>E-mail:</span><a href="#">Admin@gmail.com</a></dd>
                                                    </dl>
                                                </div>
                                            </div>
                                        </div></article>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            
            <!--==============================footer=================================-->
           <?php
		   include("cfooter.php");
		   ?>