<?php
include("cheader.php");
if (isset($_POST['submit']))
{
$qry=mysqli_query($con,"insert into customer values('".$_POST['Name']."','".$_POST['Phone']."','".$_POST['Address']."','".$_POST['City']."'
,'".$_POST['Pincode']."','".$_POST['Email']."','".$_POST['Password']."')");
		echo "<script type='text/javascript'>" ;
		echo "alert('Customer Registeration Successfully');";
		echo "window.location.href='login.php';";
		echo "</script>";
		
}
?>
                </div>
            </header>
            
            <!--==============================content================================-->
            <section id="content">
                <div class="main zerogrid">
                    <div class="col-full">
                    
                        <div class="container-bot">
                            <div class="container-top">
                                <div class="container">
                                    <div class="wrapper">
                                        <article class="col-2-3"><div class="wrap-col">
                                            <div class="indent-left">
                                                <h3 class="p1">USER Registration</h3>
                                                <form id="contact-form" method="post" enctype="multipart/form-data">                    
                                                    <fieldset>
                                                          
                                                           <label><span class="text-form">Name:</span><input name="Name" type="text" id="Name" /></label>
                                                          <label><span class="text-form">Phone:</span><input name="Phone" type="text" id="Phone" /></label>                              
                                                          <label><span class="text-form">Address:</span><input name="Address" type="text" id="Address" /></label>
															 <label><span class="text-form">City :</span><input name="City" type="text" id="City" /></label>
															 <label><span class="text-form">Pincode:</span><input name="Pincode" type="number" id="Pincode" /></label>
															 <label><span class="text-form">Email:</span><input name="Email" type="Email" id="Email" /></label>
														   <label><span class="text-form">Password:</span><input name="Password" type="Password" id="Password" /></label>
															 <div class="wrapper">
                                                           
                                                            <div class="extra-wrap">
                                                         
                                                                <div class="buttons" style="text-align: center;">
																  <input type="submit" name="submit"style="display:inline-block; 
	margin-right:16px;
	width:100px;
	font-size:13px;
	line-height:1.23em;
	font-weight:bold;
	color:#000; 
	background:url(../images/button-tail.gif) 0 0 repeat-x #fb4400;
	cursor:pointer;
	border-radius:3px;
	-moz-border-radius:3px;
	-webkit-border-radius:3px;">
	<input type="reset" name="reset"style="display:inline-block; 
	
	width:100px;
	font-size:13px;
	line-height:1.23em;
	font-weight:bold;
	color:#000; 
	background:url(../images/button-tail.gif) 0 0 repeat-x #fb4400;
	cursor:pointer;
	border-radius:3px;
	-moz-border-radius:3px;
	-webkit-border-radius:3px;">
	<br/>
	
                                                                  
                                                                </div> 
                                                            </div>
                                                          </div>                            
                                                    </fieldset>						
                                                </form>
                                            </div>
                                        </div></article>
                                
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            
            <!--==============================footer=================================-->
             <?php
		   
		   include("cfooter.php");
		   ?>