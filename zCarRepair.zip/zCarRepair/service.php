<?php
include("cheader.php");

?>
                </div>
            </header>
            
            <!--==============================content================================-->
            <section id="content">
                <div class="main zerogrid">
                    <div class="col-full">
                  
                        <div class="container-bot">
                            <div class="container-top">
                                <div class="container">
                                    <div class="wrapper">
                                       
                                         <article class="col-1-3"><div class="wrap-col">
                                       <div class="indent-left2">
                                               <h3> <strong>Services</strong></h3>
                                                <h6>We provide these services</h6>
                                                <ul class="list-2 p1">
												<?php
												$q=mysqli_query($con,"select * from services");
												while($q1=mysqli_fetch_array($q)){
												?>
                                                    <li><a href="single_service.php?sid=<?php echo $q1['S_id']; ?>"><?php echo $q1['S_name']; ?></a></li>
												<?php } ?>
                                                </ul>
                                              
                                            </div> 
                                        </div></article>
										<article class="col-1-3"><div class="wrap-col">
                                       <div class="indent-left2">
                                               <h3> <strong>Packages</strong></h3>
                                                <h6>We provide these services</h6>
                                                <ul class="list-2 p1">
												<?php
												$q=mysqli_query($con,"select * from package");
												while($q1=mysqli_fetch_array($q)){
												?>
                                                    <li><a href="single_package.php?pid=<?php echo $q1['package_id']; ?>"><?php echo $q1['Package_name']; ?></a></li>
												<?php } ?>
                                                </ul>
                                              
                                            </div> 
                                        </div></article>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            
            <!--==============================footer=================================-->
            <?php
			include("cfooter.php");
			?>