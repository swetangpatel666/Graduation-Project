<?php
include("cheader.php");
$owid=session_id();
									
											 
?>
                </div>
            </header>
            
            <!--==============================content================================-->
            <section id="content">
                <div class="main zerogrid">
                    <div class="col-full">
                       <form method="post">
                        <div class="container-bot">
                            <div class="container-top">
                                <div class="container">
                                    <div class="wrapper">
                                        <article class="col-2-3"><div class="wrap-col">
                                            <div>
											<?php
											$q=mysqli_query($con,"select * from services  ");
											
											if(isset($_GET['sid'])){
											$q=mysqli_query($con,"select * from services where S_id='".$_GET['sid']."' ");
											}
										while($q1=mysqli_fetch_array($q)){
												
											?>
                                                <h3><font color="Tomato"><?php echo $q1['S_name']; ?></font></h3>
                                                <div class="wrapper margin-bot">
													<div class="col-1-3">
                                                    <figure class="img-indent3"><img src="admin/<?php echo $q1['Image'];?>" alt=""></figure>
													</div>
                                                    <div class="col-2-3 extra-wrap">
                                                        <h6><strong>CR Price :<?php  echo 'Rs. '.$q1['Price'];?> </strong></h6>
                                                        <p><?php echo $q1['Description'];?></p>
														
														
                                                      
														<input type="hidden" value="<?php echo $q1['S_id']; ?>" name='sid'>
															<input type="hidden" value="<?php echo $q1['Price']; ?>" name='price'>
													
                                                    </div>
                                                </div>
										<?php } ?>
                                            </div>
                                        </div></article>
										
                                        
                                    </div>
                                </div>
                            </div>
                        </div></form>
                    </div>
                </div>
            </section>
            
            <!--==============================footer=================================-->
           <?php
		   include("cfooter.php");
		   ?>